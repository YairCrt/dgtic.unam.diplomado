package mx.unam.diplomado.proyecto9.repositorio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.enterprise.context.SessionScoped;
import mx.unam.diplomado.proyecto9.beans.Accesorio;
import mx.unam.diplomado.proyecto9.beans.SillaGamer;

@SessionScoped
public class SillasGamers extends Accesorio implements Serializable {
	private static final long serialVersionUID = -8086178291445439652L;
	
	private List<SillaGamerEntity> sillas = new ArrayList<SillaGamerEntity>();
	
	public String agregar(SillaGamer silla) {
		SillaGamerEntity sg = new SillaGamerEntity();
		sg.setGradoInclinacion(silla.getGradoInclinacion());
		sg.setSoportePeso(silla.getSoportePeso());
		sg.setColor(silla.getColor());
		sg.setPrecio(silla.getPrecio());
		sillas.add(sg);
		return "index";
	}
	
	public List<SillaGamerEntity> getSillasGamers(){
		return sillas;
	}
	

}
