package mx.unam.diplomado.proyecto9.beans;

import java.io.Serializable;

import jakarta.enterprise.context.SessionScoped;
@SessionScoped
public class Accesorio implements Serializable {
	static final long serialVersionUID = -2859833780766576490L;
	
	protected String precio;
	protected String color;
	
	public Accesorio() {
		// TODO Auto-generated constructor stub
	}
	
	public Accesorio(String precio, String color) {
		super();
		this.precio = precio;
		this.color = color;
	}

	public String getPrecio() {
		return precio;
	}

	public void setPrecio(String precio) {
		this.precio = precio;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "precio=" + precio + ", color=" + color + "]";
	}
	
	
	
}
