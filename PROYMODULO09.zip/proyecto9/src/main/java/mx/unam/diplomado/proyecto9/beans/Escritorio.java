package mx.unam.diplomado.proyecto9.beans;

import java.io.Serializable;
import java.util.List;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import mx.unam.diplomado.proyecto9.repositorio.EscritorioEntity;
import mx.unam.diplomado.proyecto9.repositorio.Escritorios;

@Named
@SessionScoped
public class Escritorio extends Accesorio implements Serializable {
	private static final long serialVersionUID = -3685463286425280466L;
	
	private String idEscritorio;
	private String nivelesAltura;
	private String material;
	private Escritorios escritorios;
	
	public Escritorio() {
		escritorios = new Escritorios();
	}
	
	public List<EscritorioEntity> getEscritorios(){
		return escritorios.getEscritorios();
	}

	public String getIdEscritorio() {
		return idEscritorio;
	}

	public void setIdEscritorio(String idEscritorio) {
		this.idEscritorio = idEscritorio;
	}

	public String getNivelesAltura() {
		return nivelesAltura;
	}

	public void setNivelesAltura(String nivelesAltura) {
		this.nivelesAltura = nivelesAltura;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}
	
	public String agregar() {
		escritorios.agregar(this);
		return "escritorio";
	}
	
}
