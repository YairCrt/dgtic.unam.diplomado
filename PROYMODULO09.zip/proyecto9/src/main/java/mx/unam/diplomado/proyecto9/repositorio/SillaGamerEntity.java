package mx.unam.diplomado.proyecto9.repositorio;

import java.io.Serializable;

import jakarta.enterprise.context.SessionScoped;
import mx.unam.diplomado.proyecto9.beans.Accesorio;

@SessionScoped
public class SillaGamerEntity extends Accesorio implements Serializable {
	private static final long serialVersionUID = -9007269095926552083L;

	private String idSilla;
	private String gradoInclinacion;
	private String soportePeso;
	
//	public SillaGamerEntity() {
//		// TODO Auto-generated constructor stub
//	}

	public String getIdSilla() {
		return idSilla;
	}

	public void setIdSilla(String idSilla) {
		this.idSilla = idSilla;
	}

	public String getGradoInclinacion() {
		return gradoInclinacion;
	}

	public void setGradoInclinacion(String gradoInclinacion) {
		this.gradoInclinacion = gradoInclinacion;
	}

	public String getSoportePeso() {
		return soportePeso;
	}

	public void setSoportePeso(String soportePeso) {
		this.soportePeso = soportePeso;
	}

	@Override
	public String toString() {
		return "SillaGamerEntity [idSilla=" + idSilla + ", gradoInclinacion=" + gradoInclinacion + ", soportePeso="
				+ soportePeso + super.toString();
	}
	
	
}
