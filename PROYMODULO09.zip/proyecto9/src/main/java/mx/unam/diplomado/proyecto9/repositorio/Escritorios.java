package mx.unam.diplomado.proyecto9.repositorio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.enterprise.context.SessionScoped;
import mx.unam.diplomado.proyecto9.beans.Accesorio;
import mx.unam.diplomado.proyecto9.beans.Escritorio;

@SessionScoped
public class Escritorios extends Accesorio implements Serializable {
	private static final long serialVersionUID = 7239176820635415109L;

	private List<EscritorioEntity> escritorios = new ArrayList<EscritorioEntity>();

	public String agregar(Escritorio escritorio) {
		EscritorioEntity ee = new EscritorioEntity();
		//ee.setIdEscritorio(escritorio.getIdEscritorio());
		ee.setMaterial(escritorio.getNivelesAltura());
		ee.setColor(escritorio.getMaterial());
		ee.setColor(escritorio.getColor());
		ee.setPrecio(escritorio.getPrecio());
		escritorios.add(ee);
		return "index";
	}
	
	public List<EscritorioEntity> getEscritorios(){
		return escritorios;
	}

}
