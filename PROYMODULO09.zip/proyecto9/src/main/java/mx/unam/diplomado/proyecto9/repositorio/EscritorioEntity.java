package mx.unam.diplomado.proyecto9.repositorio;

import java.io.Serializable;

import jakarta.enterprise.context.SessionScoped;
import mx.unam.diplomado.proyecto9.beans.Accesorio;

@SessionScoped
public class EscritorioEntity extends Accesorio implements Serializable {
	private static final long serialVersionUID = 5271969067432520936L;
	
	private String idEscritorio;
	private String nivelesAltura;
	private String material;
	
	public EscritorioEntity() {
		// TODO Auto-generated constructor stub
	}
	
	public String getIdEscritorio() {
		return idEscritorio;
	}
	public void setIdEscritorio(String idEscritorio) {
		this.idEscritorio = idEscritorio;
	}
	public String getNivelesAltura() {
		return nivelesAltura;
	}
	public void setNivelesAltura(String nivelesAltura) {
		this.nivelesAltura = nivelesAltura;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	@Override
	public String toString() {
		return "EscritorioEntity [idEscritorio=" + idEscritorio + ", nivelesAltura=" + nivelesAltura + ", material="
				+ material + super.toString();
	}
	
	
	
}
