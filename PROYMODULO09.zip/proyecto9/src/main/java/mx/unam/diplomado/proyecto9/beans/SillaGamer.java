package mx.unam.diplomado.proyecto9.beans;

import java.io.Serializable;
import java.util.List;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import mx.unam.diplomado.proyecto9.repositorio.SillaGamerEntity;
import mx.unam.diplomado.proyecto9.repositorio.SillasGamers;

@Named
@SessionScoped
public class SillaGamer extends Accesorio implements Serializable {
	private static final long serialVersionUID = 111042445411430337L;
	
	private String idSilla;
	private String gradoInclinacion;
	private String soportePeso;
	private SillasGamers sillas;
	
	public SillaGamer() {
		sillas = new SillasGamers();
	}
	
	public List<SillaGamerEntity> getSillasGamers(){
		return sillas.getSillasGamers();
	}

	public String getIdSilla() {
		return idSilla;
	}

	public void setIdSilla(String idSilla) {
		this.idSilla = idSilla;
	}

	public String getGradoInclinacion() {
		return gradoInclinacion;
	}

	public void setGradoInclinacion(String gradoInclinacion) {
		this.gradoInclinacion = gradoInclinacion;
	}

	public String getSoportePeso() {
		return soportePeso;
	}

	public void setSoportePeso(String soportePeso) {
		this.soportePeso = soportePeso;
	}

	public SillasGamers getSillas() {
		return sillas;
	}

	public void setSillas(SillasGamers sillas) {
		this.sillas = sillas;
	}	
	
	public String agregar() {
		sillas.agregar(this);
		return "index";
	}
	
}
