DROP DATABASE IF EXISTS proyectofinal;
CREATE DATABASE proyectofinal;
USE proyectofinal;


DROP TABLE IF EXISTS escritorios;
DROP TABLE IF EXISTS marcas;
DROP TABLE IF EXISTS sillasgamer;
DROP TABLE IF EXISTS consolas;


CREATE TABLE marcas(
	idMarca INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	nombreMarca VARCHAR(100),
	estrellas DOUBLE
);
CREATE TABLE consolas(
	idConsola INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	compañia VARCHAR(100)
);
CREATE TABLE escritorios(
	idEscritorio INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	nivelesAltura SMALLINT NOT NULL CHECK(nivelesAltura > 0 AND nivelesAltura <= 4),
	material VARCHAR(100) NOT NULL DEFAULT 'Material Inoxidable',
	precio DOUBLE NOT NULL CHECK(precio > 0),
	color VARCHAR(100) DEFAULT 'negro',
	marca_id INT DEFAULT 1
);
CREATE TABLE sillasgamer(
	idSilla INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	gradoInclinacion INT NOT NULL CHECK(gradoIncLinacion > 90 AND gradoInclinacion <= 180),
	soportePeso INT NOT NULL CHECK(soportePeso > 100 AND soportePeso <= 190),
	precio DOUBLE NOT NULL CHECK(precio > 0),
	color VARCHAR(100) NOT NULL DEFAULT 'negro',
	marca_id INT
);

INSERT INTO marcas (nombreMarca, estrellas) 
	VALUES('AudioTeck', 4.6);
INSERT INTO marcas (nombreMarca, estrellas) 
	VALUES('Randu', 3.8);
INSERT INTO marcas (nombreMarca, estrellas) 
	VALUES('HyperX', 4.2);
	
INSERT INTO escritorios(nivelesAltura, material, precio, color, marca_id)
		VALUES(3, 'madera refinada', 11000, 'azul', 1);
INSERT INTO escritorios(nivelesAltura, material, precio, color, marca_id)
		VALUES(4, 'acero inoxidable', 14700, 'gris', 2);
INSERT INTO escritorios(nivelesAltura, material, precio, color, marca_id)
		VALUES(2, 'metal reforzado', 8900, 'blanco', 2);
		
INSERT INTO sillasgamer(gradoInclinacion, soportePeso, precio, color, marca_id)
	VALUES(120, 120, 7500, 'azul marino', 3);
INSERT INTO sillasgamer(gradoInclinacion, soportePeso, precio, color, marca_id)
	VALUES(170, 150, 10300, 'negro', 1);
INSERT INTO sillasgamer(gradoInclinacion, soportePeso, precio, color, marca_id)
	VALUES(150, 110, 7900, 'rojo', 2);
	
SELECT * FROM marcas;
SELECT * FROM escritorios;
SELECT * FROM sillasgamer;