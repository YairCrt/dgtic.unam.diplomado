package dgtic.unam.dao;

import org.springframework.data.repository.CrudRepository;

import dgtic.unam.domain.Marca;

public interface IMarcaDao extends CrudRepository<Marca, Integer> {
	
}
