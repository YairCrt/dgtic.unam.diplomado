package dgtic.unam.dao;

import org.springframework.data.repository.CrudRepository;

import dgtic.unam.domain.Consola;

public interface IConsola extends CrudRepository<Consola, Integer> {

}
