package dgtic.unam.dao;

import org.springframework.data.repository.CrudRepository;

import dgtic.unam.domain.SillaGamer;

public interface ISillaDao extends CrudRepository<SillaGamer, Integer>{

}
