package dgtic.unam.dao;

import org.springframework.data.repository.CrudRepository;

import dgtic.unam.domain.Escritorio;

public interface IEscritorioDao extends CrudRepository<Escritorio, Integer> {
	
}
