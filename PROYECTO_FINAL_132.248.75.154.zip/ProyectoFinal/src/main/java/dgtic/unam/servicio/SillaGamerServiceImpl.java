package dgtic.unam.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dgtic.unam.dao.ISillaDao;
import dgtic.unam.domain.SillaGamer;

@Service
public class SillaGamerServiceImpl implements SillaGamerService {
	
	@Autowired
	private ISillaDao sillagDao;
	
	@Override
	@Transactional(readOnly = true)
	public List<SillaGamer> listarSillas() {
		return (List<SillaGamer>) sillagDao.findAll();
	}

	@Override
	@Transactional
	public void guardar(SillaGamer sillaG) {
		sillagDao.save(sillaG);
	}

	@Override
	@Transactional
	public void eliminar(SillaGamer sillaG) {
		sillagDao.delete(sillaG);
	}

	@Override
	@Transactional(readOnly = true)
	public SillaGamer buscarSilla(SillaGamer sillaG) {
		return sillagDao.findById(sillaG.getIdSilla()).orElse(null);
	}

}
