package dgtic.unam.servicio;

import java.util.List;

import dgtic.unam.domain.Escritorio;

public interface EscritorioService {
	
	public List<Escritorio> listarEscritorios();
	
	public void guardar(Escritorio escritorio);
	
	public void eliminar(Escritorio escritorio);
	
	public Escritorio buscarEscritorio(Escritorio escritorio);

}
