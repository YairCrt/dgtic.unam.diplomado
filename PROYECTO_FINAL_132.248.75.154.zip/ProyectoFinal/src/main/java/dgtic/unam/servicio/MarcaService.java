package dgtic.unam.servicio;

import java.util.List;

import dgtic.unam.domain.Marca;

public interface MarcaService {
	
	public List<Marca> listarMarcas();
	
	public void guardar(Marca marca);
	
	public void eliminar(Marca marca);
	
	public Marca buscarMarca(Marca marca);
	
}
