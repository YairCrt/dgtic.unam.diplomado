package dgtic.unam.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dgtic.unam.dao.IMarcaDao;
import dgtic.unam.domain.Marca;

@Service
public class MarcaServiceImpl implements MarcaService {
	
	@Autowired
	private IMarcaDao marcaDao;

	@Override
	@Transactional(readOnly = true)
	public List<Marca> listarMarcas() {
	 	return (List<Marca>) marcaDao.findAll();
	}

	@Override
	@Transactional
	public void guardar(Marca marca) {
		marcaDao.save(marca);
	}

	@Override
	@Transactional
	public void eliminar(Marca marca) {
		marcaDao.delete(marca);
	}

	@Override
	@Transactional(readOnly = true)
	public Marca buscarMarca(Marca marca) {
		return marcaDao.findById(marca.getIdMarca()).orElse(null);
	}

}
