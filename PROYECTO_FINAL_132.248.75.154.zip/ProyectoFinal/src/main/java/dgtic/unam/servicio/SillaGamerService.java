package dgtic.unam.servicio;

import java.util.List;

import dgtic.unam.domain.SillaGamer;

public interface SillaGamerService  {
	
public List<SillaGamer> listarSillas();
	
	public void guardar(SillaGamer sillaG);
	
	public void eliminar(SillaGamer sillaG);
	
	public SillaGamer buscarSilla(SillaGamer sillaG);
}
