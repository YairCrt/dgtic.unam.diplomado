package dgtic.unam.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dgtic.unam.dao.IEscritorioDao;
import dgtic.unam.domain.Escritorio;

@Service
public class EscritorioServiceImpl implements EscritorioService {
	
	@Autowired
	private IEscritorioDao escritorioDao;

	@Override
	@Transactional(readOnly = true)
	public List<Escritorio> listarEscritorios() {
		return (List<Escritorio>) escritorioDao.findAll();
	}

	@Override
	@Transactional
	public void guardar(Escritorio escritorio) {
		escritorioDao.save(escritorio);
		
	}

	@Override
	@Transactional
	public void eliminar(Escritorio escritorio) {
		escritorioDao.delete(escritorio);
		
	}

	@Override
	@Transactional(readOnly = true)
	public Escritorio buscarEscritorio(Escritorio escritorio) {
		return escritorioDao.findById(escritorio.getIdEscritorio()).orElse(null);
	}


}
