package dgtic.unam.domain;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class Accesorio {
	private double precio;
	private String color;
	
	public Accesorio() {
		// TODO Auto-generated constructor stub
	}

	public Accesorio(double precio, String color) {
		super();
		this.precio = precio;
		this.color = color;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Accesorio [precio=" + precio + ", color=" + color + "]";
	}
	
	
}
