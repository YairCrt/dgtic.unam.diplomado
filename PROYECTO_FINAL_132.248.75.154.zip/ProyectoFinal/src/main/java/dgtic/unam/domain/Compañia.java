package dgtic.unam.domain;

public enum Compañia {
	XBOX,
	PLAYSTATION,
	NINTENDO
}
