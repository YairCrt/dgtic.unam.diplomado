package dgtic.unam.domain;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;


@Entity
@Table(name="marcas")
public class Marca  implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idMarca;
	@NotEmpty
	private String nombreMarca;
	@Min(0)
	@Max(5)
	private double estrellas;
	
	public Marca() {
		// TODO Auto-generated constructor stub
	}

	public Marca(int idMarca) {
		super();
		this.idMarca = idMarca;
	}

	public int getIdMarca() {
		return idMarca;
	}

	public void setIdMarca(int idMarca) {
		this.idMarca = idMarca;
	}

	public String getNombreMarca() {
		return nombreMarca;
	}

	public void setNombreMarca(String nombreMarca) {
		this.nombreMarca = nombreMarca;
	}

	public double getEstrellas() {
		return estrellas;
	}

	public void setEstrellas(double estrellas) {
		this.estrellas = estrellas;
	}

	@Override
	public int hashCode() {
		return Objects.hash(estrellas, idMarca, nombreMarca);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Marca other = (Marca) obj;
		return Double.doubleToLongBits(estrellas) == Double.doubleToLongBits(other.estrellas)
				&& idMarca == other.idMarca && Objects.equals(nombreMarca, other.nombreMarca);
	}

	@Override
	public String toString() {
		return "Marca [idMarca=" + idMarca + ", nombreMarca=" + nombreMarca + ", estrellas=" + estrellas + "]";
	}
	
	
	
}
