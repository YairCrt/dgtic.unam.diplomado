package dgtic.unam.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
@Table(name = "sillasgamer")
public class SillaGamer extends Accesorio implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idSilla;
	@Min(90)
	@Max(180)
	private int gradoInclinacion;
	@Min(100)
	@Max(190)
	private int soportePeso;
	@ManyToOne
	@JoinColumn(name = "marca_id")
	private Marca marca;
	
	public SillaGamer() {
		// TODO Auto-generated constructor stub
	}

	public SillaGamer(int idSilla) {
		super();
		this.idSilla = idSilla;
	}

	public SillaGamer(int idSilla, int gradoInclinacion, int soportePeso, Marca marca) {
		super();
		this.idSilla = idSilla;
		this.gradoInclinacion = gradoInclinacion;
		this.soportePeso = soportePeso;
		this.marca = marca;
	}

	public int getIdSilla() {
		return idSilla;
	}

	public void setIdSilla(int idSilla) {
		this.idSilla = idSilla;
	}

	public int getGradoInclinacion() {
		return gradoInclinacion;
	}

	public void setGradoInclinacion(int gradoInclinacion) {
		this.gradoInclinacion = gradoInclinacion;
	}

	public int getSoportePeso() {
		return soportePeso;
	}

	public void setSoportePeso(int soportePeso) {
		this.soportePeso = soportePeso;
	}

	public Marca getMarca() {
		return marca;
	}

	public void setMarca(Marca marca) {
		this.marca = marca;
	}

	@Override
	public String toString() {
		return "SillaGamer [idSilla=" + idSilla + ", gradoInclinacion=" + gradoInclinacion + ", soportePeso="
				+ soportePeso + ", marca=" + marca.getNombreMarca() + "]";
	}
	
	
}
