package dgtic.unam.domain;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "compañias")
public class Consola {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idConsola;
	@Enumerated(value = EnumType.STRING)
	private Compañia compañia;
	
	public Consola() {
		// TODO Auto-generated constructor stub
	}

	public Consola(int idConsola) {
		super();
		this.idConsola = idConsola;
	}
	

	public Consola(int idConsola, Compañia compañia) {
		super();
		this.idConsola = idConsola;
		this.compañia = compañia;
	}

	public int getIdConsola() {
		return idConsola;
	}

	public void setIdConsola(int idConsola) {
		this.idConsola = idConsola;
	}

	public Compañia getCompañia() {
		return compañia;
	}

	public void setCompañia(Compañia compañia) {
		this.compañia = compañia;
	}

	@Override
	public String toString() {
		return "Consola [idConsola=" + idConsola + ", compañia=" + compañia + "]";
	}
	
}
