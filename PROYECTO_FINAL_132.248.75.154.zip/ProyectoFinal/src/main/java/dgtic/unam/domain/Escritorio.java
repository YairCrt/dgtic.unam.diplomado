package dgtic.unam.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "escritorios")
public class Escritorio extends Accesorio implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idEscritorio;
	@Min(1)
	@Max(4)
	private int nivelesAltura;
	@NotEmpty
	private String material;
	@ManyToOne
	@JoinColumn(name = "marca_id")
	private Marca marca;
	
	public Escritorio() {
		// TODO Auto-generated constructor stub
	}
	
	public Escritorio(int idEscritorio) {
		super();
		this.idEscritorio = idEscritorio;
	}

	public Escritorio(int idEscritorio, int nivelesAltura, String material, Marca marca) {
		super();
		this.idEscritorio = idEscritorio;
		this.nivelesAltura = nivelesAltura;
		this.material = material;
		this.marca = marca;
	}

	public int getIdEscritorio() {
		return idEscritorio;
	}

	public void setIdEscritorio(int idEscritorio) {
		this.idEscritorio = idEscritorio;
	}

	public int getNivelesAltura() {
		return nivelesAltura;
	}

	public void setNivelesAltura(int nivelesAltura) {
		this.nivelesAltura = nivelesAltura;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public Marca getMarca() {
		return marca;
	}

	public void setMarca(Marca marca) {
		this.marca = marca;
	}

	@Override
	public String toString() {
		return "Escritorio [idEscritorio=" + idEscritorio + ", nivelesAltura=" + nivelesAltura + ", material="
				+ material + ", marca=" + marca.getNombreMarca() + "]";
	}
	
}
