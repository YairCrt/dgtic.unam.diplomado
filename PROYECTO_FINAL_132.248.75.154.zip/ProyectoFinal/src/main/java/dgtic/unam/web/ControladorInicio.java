package dgtic.unam.web;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import dgtic.unam.domain.Marca;
import dgtic.unam.servicio.MarcaService;

@Controller
public class ControladorInicio {
	@Autowired
	private ServletContext servletContext;
	@Autowired 
	MarcaService marcaService;
	
	@GetMapping("/")
	public String Inicio() {
		List<Marca> marcas = marcaService.listarMarcas();
		List<Integer> listaMarca = new ArrayList<Integer>();
		for (Marca marca : marcas) {
			listaMarca.add(marca.getIdMarca());
		}
		servletContext.setAttribute("marcaList", listaMarca);
		return "index";
	}
	
}
