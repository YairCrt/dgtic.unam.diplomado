package dgtic.unam.web;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import dgtic.unam.domain.SillaGamer;
import dgtic.unam.servicio.MarcaService;
import dgtic.unam.servicio.SillaGamerService;

@Controller
@RequestMapping("/sillasgamer")
public class ControladorSillaGamer {
	
	@Autowired
	private SillaGamerService sillaGService;
	@Autowired
	private MarcaService marcaService;
	
	@GetMapping("/listarSillas")
	public String InicioSillas(Model model) {
		Iterable<SillaGamer> sillas = sillaGService.listarSillas();
		model.addAttribute("sillasgamer", sillas);
		return "sillasgamer";
	}
	
	@GetMapping("/agregarSilla")
	public String agregarSilla(SillaGamer sillaGamer) {
		return "modificarSilla";
	}
	
	@PostMapping("/guardarSilla")
	public String guardarSilla(@Valid SillaGamer sillaGamer, Errors errores) {
		if(errores.hasErrors()) {
			return "modificarSilla";
		}
		marcaService.buscarMarca(sillaGamer.getMarca());
		sillaGService.guardar(sillaGamer);
		return "redirect:/sillasgamer/listarSillas";
	}
	
	@GetMapping("/editarSilla/{idSilla}")
	public String editarSilla(SillaGamer sillaGamer, Model model) {
		sillaGamer = sillaGService.buscarSilla(sillaGamer);
		model.addAttribute("sillaGamer", sillaGamer);
		return "modificarSilla";
	}
	
	@GetMapping("/eliminarSilla/{idSilla}")
	public String eliminarSilla(SillaGamer sillaGamer) {
		sillaGService.eliminar(sillaGamer);
		return "redirect:/sillasgamer/listarSillas";
	}
}
