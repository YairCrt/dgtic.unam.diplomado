package dgtic.unam.web;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import dgtic.unam.domain.Marca;
import dgtic.unam.servicio.MarcaService;

@Controller
@RequestMapping("/marcas")
public class ControladorMarca {
	
	@Autowired
	private MarcaService marcaService;
	
	@GetMapping("/listarMarcas")
	public String InicioMarcas(Model model) {
		Iterable<Marca> marcas = marcaService.listarMarcas();
		model.addAttribute("marcas", marcas);
		return "marcas";
	}
	
	@GetMapping("/agregarMarca")
	public String agregarMarca(Marca marca) {
		return "modificarMarca";
	}
	
	@PostMapping("/guardarMarca")
	public String guardarMarca(@Valid Marca marca, Errors errores) {
		if(errores.hasErrors()) {
			return "modificarMarca";
		}
		marcaService.guardar(marca);
		return "redirect:/marcas/listarMarcas";
	}
	
	@GetMapping("/editarMarca/{idMarca}")
	public String editarMarca(Marca marca, Model model) {
		marca = marcaService.buscarMarca(marca);
		model.addAttribute("marca", marca);
		return "modificarMarca";
	}
	
	@GetMapping("/eliminarMarca/{idMarca}")
	public String eliminarMarca(Marca marca) {
		marcaService.eliminar(marca);
		return "redirect:/marcas/listarMarcas";
	}
}
