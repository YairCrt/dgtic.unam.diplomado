package dgtic.unam.web;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import dgtic.unam.domain.Escritorio;
import dgtic.unam.servicio.EscritorioService;
import dgtic.unam.servicio.MarcaService;

@Controller
@RequestMapping("/escritorios")
public class ControladorEscritorio {
	
	@Autowired
	private EscritorioService escritorioService;
	@Autowired
	private MarcaService marcaService;
	
	@GetMapping("/listarEscritorios")
	public String InicioEscritorios(Model model) {
		Iterable<Escritorio> escritorios = escritorioService.listarEscritorios();
		model.addAttribute("escritorios", escritorios);
		return "escritorios";
	}
	
	@GetMapping("/agregarEscritorio")
	public String agregarEscritorio(Escritorio escritorio) {
		return "modificarEscritorio";
	}
	
	@PostMapping("/guardarEscritorio")
	public String guardarEscritorio(@Valid Escritorio escritorio, Errors errores) {
		if(errores.hasErrors()) {
			return "modificarEscritorio";
		}
		marcaService.buscarMarca(escritorio.getMarca());
		escritorioService.guardar(escritorio);
		return "redirect:/escritorios/listarEscritorios";
	}
	
	@GetMapping("/editarEscritorio/{idEscritorio}")
	public String editarEscritorio(Escritorio escritorio, Model model) {
		escritorio = escritorioService.buscarEscritorio(escritorio);
		model.addAttribute("escritorio", escritorio);
		return "modificarEscritorio";
	}
	
	@GetMapping("/eliminarEscritorio/{idEscritorio}")
	public String eliminarEscritorio(Escritorio escritorio) {
		escritorioService.eliminar(escritorio);
		return "redirect:/escritorios/listarEscritorios";
	}

}
